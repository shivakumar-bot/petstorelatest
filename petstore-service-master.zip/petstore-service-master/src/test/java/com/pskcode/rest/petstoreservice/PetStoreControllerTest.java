package com.pskcode.rest.petstoreservice;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pskcode.rest.petstoreservice.controller.PetStoreController;
import com.pskcode.rest.petstoreservice.domain.CategoryEntity;
import com.pskcode.rest.petstoreservice.domain.PetStoreEntity;
import com.pskcode.rest.petstoreservice.domain.TagEntity;
import com.pskcode.rest.petstoreservice.dto.CategoryDTO;
import com.pskcode.rest.petstoreservice.dto.PetStoreDTO;
import com.pskcode.rest.petstoreservice.dto.TagDTO;
import com.pskcode.rest.petstoreservice.repository.PetStoreRepository;
import com.pskcode.rest.petstoreservice.service.PetStoreService;

@WebMvcTest(PetStoreController.class)
@ComponentScan(basePackages = { "com.pskcode.rest.petstoreservice.*" })
public class PetStoreControllerTest {

	@Autowired
	private MockMvc mvc;

	@Autowired
	PetStoreService petStoreService;

	@MockBean
	private PetStoreRepository petStoreRepository;

	@Autowired
	ModelMapper modelMapper;

	  @Autowired
	  private ObjectMapper objectMapper;

	
	@Test
	void givenPetStoreDetails_when_called_to_service() throws Exception {

		// given
		CategoryEntity category = new CategoryEntity();
		TagEntity tagEntity1 = new TagEntity();
		TagEntity tagEntity2 = new TagEntity();
		TagEntity tagEntity3 = new TagEntity();
		PetStoreEntity petStoreEntity = new PetStoreEntity();
		tagEntity1.setTagName("Tag_Dog1");
		tagEntity1.setTagId(1);
		tagEntity2.setTagName("Tag_Dog2");
		tagEntity2.setTagId(2);
		tagEntity3.setTagName("Tag_Dog3");
		tagEntity3.setTagId(3);
		List<TagEntity> tags = new ArrayList<>();
		tags.add(tagEntity1);
		tags.add(tagEntity2);
		tags.add(tagEntity3);
		petStoreEntity.setTags(tags);

		category.setCategoryId(1);
		category.setCategoryName("Animal");
		petStoreEntity.setCategory(category);

		petStoreEntity.setName("Angle");
		petStoreEntity.setPetId(1);
		petStoreEntity.setStatus("AVAILABLE");
		petStoreEntity.setColors(Arrays.asList("http:boggie", "http:bniufid"));

		List<PetStoreEntity> petStoreDetails = Arrays.asList(petStoreEntity);
		Type listType = new TypeToken<List<PetStoreDTO>>() {
		}.getType();
		List<PetStoreDTO> postDtoList = modelMapper.map(petStoreDetails, listType);

		given(petStoreService.getAllDetailsOfPetFromPetStore()).willReturn(postDtoList);

		// when + then
		mvc.perform(get("/api/petstore/v1/")).andExpect(status().isOk())
				.andExpect(content().json("[\r\n" + "    {\r\n" + "        \"petId\": 1,\r\n"
						+ "        \"name\": \"Angle\",\r\n" + "        \"status\": \"AVAILABLE\",\r\n"
						+ "        \"colors\": [\r\n" + "            \"http:boggie\",\r\n"
						+ "            \"http:bniufid\"\r\n" + "        ],\r\n" + "        \"category\": {\r\n"
						+ "            \"categoryId\": 1,\r\n" + "            \"categoryName\": \"Animal\"\r\n"
						+ "        },\r\n" + "        \"tags\": [\r\n" + "            {\r\n"
						+ "                \"tagId\": 1,\r\n" + "                \"tagName\": \"Tag_Dog1\"\r\n"
						+ "            },\r\n" + "            {\r\n" + "                \"tagId\": 2,\r\n"
						+ "                \"tagName\": \"Tag_Dog2\"\r\n" + "            },\r\n" + "            {\r\n"
						+ "                \"tagId\": 3,\r\n" + "                \"tagName\": \"Tag_Dog3\"\r\n"
						+ "            }\r\n" + "        ]\r\n" + "    }\r\n" + "]"));

	}



	/**
	 * Maps an Object into a JSON String. Uses a Jackson ObjectMapper.
	 */
	private String mapToJson(Object object) throws JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		return objectMapper.writeValueAsString(object);
	}


	
	private PetStoreEntity  getAddedObject() {
		CategoryEntity category = new CategoryEntity();
		TagEntity tagEntity1 = new TagEntity();
		TagEntity tagEntity2 = new TagEntity();
		TagEntity tagEntity3 = new TagEntity();
		PetStoreEntity petStoreEntity = new PetStoreEntity();
		tagEntity1.setTagName("Tag_Dog1");
		tagEntity1.setTagId(1);
		tagEntity2.setTagName("Tag_Dog2");
		tagEntity2.setTagId(2);
		tagEntity3.setTagName("Tag_Dog3");
		tagEntity3.setTagId(3);
		List<TagEntity> tags = new ArrayList<>();
		tags.add(tagEntity1);
		tags.add(tagEntity2);
		tags.add(tagEntity3);
		petStoreEntity.setTags(tags);

		category.setCategoryId(1);
		category.setCategoryName("Animal");
		petStoreEntity.setCategory(category);
		petStoreEntity.setPetId(100);
		petStoreEntity.setName("Angle");
		petStoreEntity.setStatus("AVAILABLE");
		petStoreEntity.setColors(Arrays.asList("http:boggie", "http:bniufid"));
		return petStoreEntity;

	}
	
	@Test
	  void whenValidInput_thenReturnsUserResource() throws Exception {
		CategoryDTO category = new CategoryDTO();
		category.setCategoryName("Animal");
		TagDTO tagEntity1 = new TagDTO("Tag_Dog1");
		TagDTO tagEntity2 = new TagDTO("Tag_Dog1");
		TagDTO tagEntity3 = new TagDTO("Tag_Dog1");
		List<TagDTO> tags = new ArrayList<>();
		tags.add(tagEntity1);
		tags.add(tagEntity2);
		tags.add(tagEntity3);
		List<String> colors = Arrays.asList("http:boggie", "http:bniufid");		
		PetStoreDTO pet = new PetStoreDTO("Angle", "AVAILABLE",colors,category,tags);
		PetStoreEntity newEntityAboutToAdd = modelMapper.map(pet, PetStoreEntity.class);
		
		
		PetStoreEntity mockAddedPetResponse = getAddedObject();
		PetStoreDTO addedPetFromEntityToDTO = modelMapper.map(mockAddedPetResponse, PetStoreDTO.class);

		//given(petStoreService.addPetIntoPetStore(pet)).willReturn(newlyAdded);
		given(petStoreRepository.save(newEntityAboutToAdd)).willReturn(mockAddedPetResponse);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/api/petstore/v1/").accept(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(pet)).contentType(MediaType.APPLICATION_JSON);

		MvcResult result = mvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response = result.getResponse();

		
		/*
		 * MvcResult mvcResult = mvc.perform(post("/api/petstore/v1/")
		 * .contentType("application/json")
		 * .content(objectMapper.writeValueAsString(pet)))
		 * .andExpect(status().isCreated()) .andReturn();
		 */
	    PetStoreDTO expectedResponseBody = addedPetFromEntityToDTO;
	    String actualResponseBody = result.getResponse().getContentAsString();
	    assertEquals(HttpStatus.CREATED.value(), response.getStatus());
	    assertThat(objectMapper.writeValueAsString(expectedResponseBody))
	            .isEqualToIgnoringWhitespace(actualResponseBody);

	  }

}
