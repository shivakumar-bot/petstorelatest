package com.pskcode.rest.petstoreservice.dto;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.NotEmpty;

import com.pskcode.rest.petstoreservice.domain.TagEntity;
import com.pskcode.rest.petstoreservice.exception.EnumValidator;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
//@AllArgsConstructor
@NoArgsConstructor
public class PetStoreDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1821327545466313323L;
	
	private Integer petId;

	@NotEmpty(message="{app.error.message.petNameShouldNotBeEmpty}")
	private String name;

	
	 @EnumValidator(
	     message = "{app.error.message.petstatusnotavailable}", enumClazz = StatusType.class
	 )
	 private String status;
	 
	 enum StatusType{
		 AVAILABLE, SOLD, PENDING;
		 
	 }

	 private List<String> colors;

	 private CategoryDTO category;
	 
	 private List<TagDTO> tags;

	public PetStoreDTO(@NotEmpty(message = "{app.error.message.petNameShouldNotBeEmpty}") String name,
			String status, List<String> colors, CategoryDTO category, List<TagDTO> tags) {
		super();
		this.name = name;
		this.status = status;
		this.colors = colors;
		this.category = category;
		this.tags = tags;
	}
	 
	  
	 
}
