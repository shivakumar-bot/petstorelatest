package com.pskcode.rest.petstoreservice.controller;

import java.util.List;

import org.springframework.data.domain.Page;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PageDecorator<T> {
	
    private final Page<T> page;

    @JsonProperty("data") // override property name in json
    public List<T> getContent() {
        return this.page.getContent();
    }


    public PageDecorator(Page<T> page) {
        this.page = page;
    }

    
    public int getTotalPages() {
        return page.getTotalPages();
    }

    public long getTotalElements() {
        return page.getTotalElements();
    }


    public int getNumber() {
    	return page.getNumber();
    }
    
    public int getsize() {
    	return page.getSize();
    }
    
    
    public boolean isLastPage() {
    	return page.isLast();
    }
    
    public boolean isFirstPage() {
    	return page.isFirst();
    }
   
}
