package com.pskcode.rest.petstoreservice.domain;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

import lombok.Data;

@Table(name = "PETSTORE")
@Entity
@Data
public class PetStoreEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8210792154735157381L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "PETID", updatable = false)
	private Integer petId;

	@Column(name = "PETNAME")
	@NotEmpty
	private String name;

	@Column(name = "STATUS")
	@NotEmpty
	private String status;

	@ElementCollection
	@NotEmpty
	@Column(name ="COLORS")
	private List<String> colors;		

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="CATEGORY_ID")
	private CategoryEntity category;
	
	/*
	 * Unidirectional- using foreign key
	 * @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval =
	 * true)
	 * 
	 * @JoinColumn(name ="PETID")
	 */
	@OneToMany(cascade = CascadeType.ALL, fetch=FetchType.EAGER, orphanRemoval = true)
    @JoinTable(
            name = "PET_TAG_JOIN_TABLE",
            joinColumns = @JoinColumn(name = "PETID"),
            inverseJoinColumns = @JoinColumn(name = "TAG_ID")
            )
	private List<TagEntity> tags;
}
