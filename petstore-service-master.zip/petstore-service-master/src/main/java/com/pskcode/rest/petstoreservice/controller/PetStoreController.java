package com.pskcode.rest.petstoreservice.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pskcode.rest.petstoreservice.dto.PetStoreDTO;
import com.pskcode.rest.petstoreservice.exception.ResourceNotFoundException;
import com.pskcode.rest.petstoreservice.service.PetStoreService;

@RestController
@RequestMapping("/api/petstore/v1/")
public class PetStoreController {
	
	Logger logger = LoggerFactory.getLogger(PetStoreController.class);
	
	
	@Autowired
	PetStoreService petStoreService;

	@Value("${app.error.message.petNotFoundMessage}")
	private String petNotFoundMessage;
	
	
	@GetMapping
	public  ResponseEntity<List<PetStoreDTO>> getPetDetailsFromStore(){
		logger.debug("getPetDetailsFromStore() method called to get Pet Details from store "+PetStoreController.class);
		List<PetStoreDTO> petDetails = petStoreService.getAllDetailsOfPetFromPetStore();
		if(CollectionUtils.isEmpty(petDetails)) {
			logger.error("Pet Details are not found in Petstore");
			throw new ResourceNotFoundException(petNotFoundMessage);
		}		
		HttpHeaders headers = new HttpHeaders();
        headers.add("Responded", "PetStoreController");
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        logger.debug("getPetDetailsFromStore() method ended to get Pet Details from store "+PetStoreController.class);
        return ResponseEntity.ok().headers(headers).body(petDetails);	
	}
	
	@PostMapping
	public ResponseEntity<PetStoreDTO> addPetDetailsIntoPetStore(@Valid @RequestBody PetStoreDTO petStoreDTO) throws URISyntaxException{
		logger.debug("addPetDetailsIntoPetStore() method is called to store the details");
		PetStoreDTO createdPetInPetStore = petStoreService.addPetIntoPetStore(petStoreDTO);
		if(null == createdPetInPetStore.getPetId()) {
			logger.error("Pet is not added in Petstore with provided details");
			throw new ResourceNotFoundException(petNotFoundMessage);
		}				
		HttpHeaders headers = new HttpHeaders();
        headers.add("Responded", "addPetDetailsIntoPetStore");
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        logger.debug("getPetDetailsFromStore() method ended to get Pet Details from store "+PetStoreController.class);
        URI locationOfURI = new URI("http://localhost:8088/restapi/api/petstore/v1/");
		return ResponseEntity.created(locationOfURI).headers(headers).body(createdPetInPetStore);
	}
	
	@GetMapping(value= "/petstores/{petId}")
	public ResponseEntity<PetStoreDTO> getPetDetailsByPetId(@PathVariable @NotEmpty Integer petId){
		logger.debug("getPetDetailsByPetId() method is called to store the details");
		PetStoreDTO petDetails = petStoreService.getPetDetailsById(petId);
		if(null == petDetails.getPetId()) {
			logger.error("Pet is not added in Petstore with provided details");
			throw new ResourceNotFoundException(petNotFoundMessage);
		}
		HttpHeaders headers = new HttpHeaders();
        headers.add("Responded", "getPetDetailsByPetId");
        headers.setContentType(MediaType.APPLICATION_JSON);
        logger.debug("getPetDetailsByPetId() method ended to get Pet Details from store "+PetStoreController.class);
		return ResponseEntity.ok().headers(headers).body(petDetails);
	}

}
