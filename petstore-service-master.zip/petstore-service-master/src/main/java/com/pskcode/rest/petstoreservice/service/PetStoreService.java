package com.pskcode.rest.petstoreservice.service;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;

import com.pskcode.rest.petstoreservice.dto.PetStoreDTO;

public interface PetStoreService {
	

	public List<PetStoreDTO> getAllDetailsOfPetFromPetStore();

	public PetStoreDTO addPetIntoPetStore(@Valid PetStoreDTO petStoreDTO);

	public PetStoreDTO getPetDetailsById(@NotEmpty Integer petId);

}
