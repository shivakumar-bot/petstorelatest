package com.pskcode.rest.petstoreservice.exception;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@ToString
public class ErrorResponse {

	public ErrorResponse(Integer errorCode, String message, List<String> details) {
		super();
		this.errorCode = errorCode;
		this.message = message;
		this.details = details;
	}

	private Integer errorCode;
	
	private String message;
	
	private List<String> details;
	
	public ErrorResponse(String message, List<String> details) {
        super();
        this.message = message;
        this.details = details;
    }
 
 
	
	
}
