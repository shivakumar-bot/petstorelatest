package com.pskcode.rest.petstoreservice.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name ="TAGS")
@Data
public class TagEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1860380181493418270L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name ="TAG_ID")
	private Integer tagId;
	
	
	@Column(name = "TAG_NAME")
	private String tagName;	
	
}
