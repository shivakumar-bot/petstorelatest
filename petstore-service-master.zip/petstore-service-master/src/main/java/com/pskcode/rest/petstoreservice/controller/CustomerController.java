package com.pskcode.rest.petstoreservice.controller;

public class CustomerController {



	/*
	 * @GetMapping(value = "/customers/{customerId}") public Customer
	 * findByCustomerId(@PathVariable Integer customerId) { return
	 * customerRepository.findById(customerId).orElseThrow( () -> new
	 * ResourceNotFoundException("Customer [customerId=" + customerId +
	 * "] can't be found")); }
	 * 
	 * @DeleteMapping(value = "/customers/{customerId}") public ResponseEntity<?>
	 * deleteCustomer(@PathVariable Integer customerId) {
	 * 
	 * return customerRepository.findById(customerId).map(customer -> {
	 * customerRepository.delete(customer); return ResponseEntity.ok().build();
	 * }).orElseThrow(() -> new ResourceNotFoundException("Customer [customerId=" +
	 * customerId + "] can't be found"));
	 * 
	 * }
	 * 
	 * @PutMapping(value = "/customers/{customerId}") public
	 * ResponseEntity<Customer> updateCustomer(@PathVariable Integer customerId,
	 * 
	 * @RequestBody Customer newCustomer) { return
	 * customerRepository.findById(customerId).map(customer -> {
	 * customer.setCustomerName(newCustomer.getCustomerName());
	 * customer.setDateofBirth(newCustomer.getDateofBirth());
	 * customer.setPhoneNumber(newCustomer.getPhoneNumber());
	 * customerRepository.save(customer); return ResponseEntity.ok(customer);
	 * }).orElseThrow(() -> new ResourceNotFoundException("Customer [customerId=" +
	 * customerId + "] can't be found"));
	 * 
	 * }
	 */

}
