package com.pskcode.rest.petstoreservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pskcode.rest.petstoreservice.domain.PetStoreEntity;

@Repository
public interface PetStoreRepository extends JpaRepository<PetStoreEntity, Integer>{
		
	PetStoreEntity findByName(String name);
	
	
}
