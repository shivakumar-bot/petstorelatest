package com.pskcode.rest.petstoreservice.service;

import java.lang.reflect.Type;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pskcode.rest.petstoreservice.domain.PetStoreEntity;
import com.pskcode.rest.petstoreservice.dto.PetStoreDTO;
import com.pskcode.rest.petstoreservice.repository.PetStoreRepository;

@Service
public class PetStoreServiceImpl implements PetStoreService {

	Logger logger = LoggerFactory.getLogger(PetStoreServiceImpl.class);

	@Autowired
	private PetStoreRepository petStoreRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Override
	public List<PetStoreDTO> getAllDetailsOfPetFromPetStore() {
		logger.debug("getAllDetailsOfPetFromPetStosre() method is called");
		List<PetStoreEntity> petStoreDetails = petStoreRepository.findAll();
		Type listType = new TypeToken<List<PetStoreDTO>>() {
		}.getType();
		List<PetStoreDTO> postDtoList = modelMapper.map(petStoreDetails, listType);
		logger.debug("getAllDetailsOfPetFromPetStore() method is ended");
		return postDtoList;
	}

	@Override
	public PetStoreDTO addPetIntoPetStore(@Valid PetStoreDTO petStoreDTO) {
		logger.debug("addPetIntoPetStore() method is called");
		PetStoreEntity pet = modelMapper.map(petStoreDTO, PetStoreEntity.class);
		PetStoreEntity addedPet = petStoreRepository.save(pet);
		PetStoreDTO newlyAdded = modelMapper.map(addedPet, PetStoreDTO.class);
		return newlyAdded;
	}

	@Override
	public PetStoreDTO getPetDetailsById(@NotEmpty Integer petId) {
		logger.debug("getPetDetailsById() method is called");
		Optional<PetStoreEntity> petStoreEntity = petStoreRepository.findById(petId);
		PetStoreDTO petDetails = modelMapper.map(petStoreEntity, PetStoreDTO.class);
		return petDetails;
	}

}
